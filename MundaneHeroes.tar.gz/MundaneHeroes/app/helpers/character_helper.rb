module CharacterHelper
end
