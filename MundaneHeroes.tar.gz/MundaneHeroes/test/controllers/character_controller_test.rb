require 'test_helper'

class CharacterControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
