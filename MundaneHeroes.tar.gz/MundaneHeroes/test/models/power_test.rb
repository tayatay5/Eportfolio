require 'test_helper'

class PowerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
